#include <iostream>
#include <string>

using namespace std;

//"garima" - more than one char - string

int main()
{
    string name;

    cout<<"Enter your name: ";
    //cin>>name;

    getline(cin, name);

    cout<<"Your name is: "<<name;

    return 0;
}
