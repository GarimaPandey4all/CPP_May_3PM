#include <iostream>

using namespace std;

/*
    constructor - special method, because class name and constructor name both are same
    It is used to initialize the instance variables
    constructor call when class's object is created.
*/

class HelloWorld {
public:
    HelloWorld(){ // constructor
        cout<<"Hello World"<<endl;
    }
};

int main()
{
    HelloWorld obj;

    return 0;
}
