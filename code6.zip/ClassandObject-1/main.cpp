#include <iostream>

using namespace std;

/*
    C++ : Object Oriented Programming Language

    OOPS Features:
    1. Class(Category) - Logical Entity, Object - Physical Entity
    2. Encapsulation and abstraction
    3. Inheritance
    4. Polymorphism

    Exception Handling
    Templates
    STL - Standard Template Library
*/

class HelloWorld{

    /*
    1. Data Member (Variables)
    2. Member Functions (Method)
    */

    /*
    Access Specifier / Modifier

    1. private - accessible by only class members
    2. public - accessible from anyone
    3. protected - inheritance
    */
public:
    void showData(){
        cout<<"Hello World"<<endl;
    }
};

int main()
{
    HelloWorld obj;
    HelloWorld obj1;

    obj.showData();
    obj1.showData();

    return 0;
}
