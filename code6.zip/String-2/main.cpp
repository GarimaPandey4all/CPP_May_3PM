#include <iostream>

using namespace std;

int main()
{
    string str1;
    string str2;
    string fullName;

    cout<<"Enter First Name: ";
    cin>>str1;

    cout<<"Enter Last Name: ";
    cin>>str2;

    fullName = str1 + str2; // + : Concatenation/Joining

    cout<<"Full Name is " <<fullName<<endl;

    cout<<"Length of the full name:"<<fullName.size()<<endl;

    return 0;
}
