#include <iostream>

using namespace std;

class Calculator { // Encapsulation - Class
public:
    int a, b; // Instance Variables

    void getData(int a, int b) // int a, b - local variables
    {
        this->a = a;
        this->b = b;
    }

    void showData()
    {
        cout<<"Addition: "<<(a + b)<<endl;
        cout<<"Subtraction: "<<(a - b)<<endl;
        cout<<"Multiplication: "<<(a * b)<<endl;
        cout<<"Division: "<<(a / b)<<endl;
    }
};

int main()
{
    Calculator obj;

    obj.getData(10, 20);
    obj.showData();

    return 0;
}
