#include <iostream>

using namespace std;

class Basic {
public:
    void showData();
};

void Basic::showData() // :: - scope resolution operator
{
    cout<<"Hello World";
}

int main()
{
    Basic obj;
    obj.showData();

    return 0;
}
