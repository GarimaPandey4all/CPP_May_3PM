#include <iostream>

using namespace std;

class Calculator {
public:
    int a, b; // Instance Variable

    void getData()
    {
        cout<<"Enter value for a and b:";
        cin>>a>>b;
    }

    void showData()
    {
        cout<<"Addition: "<<(a + b)<<endl;
        cout<<"Subtraction: "<<(a - b)<<endl;
        cout<<"Multiplication: "<<(a * b)<<endl;
        cout<<"Division: "<<(a / b)<<endl;
    }
};

int main()
{
    Calculator obj;

    obj.getData();
    obj.showData();

    return 0;
}
