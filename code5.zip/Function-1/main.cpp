#include <iostream>

using namespace std;

/*
    Function has four types"

    1. Function without arguments and without return type.
    2. Function without arguments and with return type.
    3. Function with arguments and without return type.
    4. Function with arguments and with return type.

*/

//1. Function without arguments and without return type.

void add(); // function declaration

int main()
{
    //function calling
    add();
    add();

    return 0;
}

//Function Definition
void add() // function prototype
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"Addition is:"<<(a + b)<<endl;
}
