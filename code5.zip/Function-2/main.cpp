#include <iostream>

using namespace std;

//2. Function without arguments and with return type.

int add(); // function declaration

int main()
{
    //function calling
   int result = add();

   cout<<"Addition is:"<<result<<endl;

    return 0;
}

//Function Definition
int add() // function prototype
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    return (a + b);
}
