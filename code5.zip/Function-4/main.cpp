#include <iostream>

using namespace std;

//4. Function with arguments and with return type.

int add(int, int);

int main()
{
    int result = add(70, 90);
    cout<<"Addition is: "<<result<<endl;

    return 0;
}


int add(int a, int b)
{
    return (a + b);
}

