#include <iostream>

using namespace std;

//3. Function with arguments and without return type.

void add(int, int); // function declaration

int main()
{
    //function calling
    add(30, 50); // Arguments - Actual Arguments

    return 0;
}

//Function Definition
void add(int a, int b) // function parameters- Formal Arguments
{
    cout<<"Addition is:"<<(a + b)<<endl;
}
