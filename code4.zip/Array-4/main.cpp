#include <iostream>
#define N 5

/*
    1   2   3
    4   5   6
    7   8   9

    PD - 1 5 9

    00  01  02
    10  11  12
    20  21  22
*/

using namespace std;

int main()
{
    //Principle Diagonal Matrix
    int matrix1[N][N], i, j, rows, cols;

    cout<<"Enter rows:";
    cin>>rows;

    cout<<"Enter columns:";
    cin>>cols;

    cout<<"Enter values in matrix - 1:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Values in matrix - 1 are:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    cout<<"Principle Diagonal is:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            if(i == j)
            {
                cout<<matrix1[i][j]<<"\t";
            }
        }
    }

    return 0;
}
