#include <iostream>

using namespace std;

/*
    Array - It is a collection of similar types of data.
            It is contiguous memory location.
            It is a homogeneous(same kind) mixture.

            In array, indexing starts from 0 to n-1

            Array - 1D
            Array - Multi-D
*/

int main()
{
    //int a[5];
    // it is a declaration of an array, 5 size of the array, [] - subscript operator

    //Traditional way of initialization
    //int var[5] = {1, 2, 3, 4, 5}; // declaration and initialization
//
//    cout<<var[0]<<endl;
//    cout<<var[3]<<endl;

//    int arr[5];
//
//    cout<<"Enter values:" ;
//    for(int i = 0; i < 5; i++)
//    {
//        cin>>arr[i];
//    }
//
//    cout<<"Values in Array are:";
//    for(int i = 0; i < 5; i++)
//    {
//        cout<<arr[i]<<" ";
//    }

    //Compile Time Initialization
    int arr[] = {1, 2, 3};

    cout<<arr[0];


    return 0;
}
