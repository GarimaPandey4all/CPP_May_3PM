#include <iostream>
#define N 5 //Macros-constant

using namespace std;

/*
    Array - 2D, Matrix , Table

    int arr[2][3]; 2 - rows, 3 - columns

*/

int main()
{
    int matrix1[N][N], matrix2[N][N], result[N][N], i, j, rows, cols;

    cout<<"Enter rows:";
    cin>>rows;

    cout<<"Enter columns:";
    cin>>cols;

    cout<<"Enter values in matrix - 1:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Enter values in matrix - 2:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cin>>matrix2[i][j];
        }
    }


    cout<<"Values in matrix - 1 are:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }


    cout<<"Values in matrix - 2 are:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cout<<matrix2[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }

    cout<<"Addition:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cout<<result[i][j]<<"\t";
        }
        cout<<endl;
    }

    return 0;
}
