#include <iostream>
#define N 5

using namespace std;

int main()
{
    //Sparse Matrix
    int matrix1[N][N], i, j, rows, cols, totalCount = 0;

    cout<<"Enter rows:";
    cin>>rows;

    cout<<"Enter columns:";
    cin>>cols;

    cout<<"Enter values in matrix - 1:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cin>>matrix1[i][j];
        }
    }

    cout<<"Values in matrix - 1 are:\n";
    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            cout<<matrix1[i][j]<<"\t";
        }
        cout<<endl;
    }

    for(i = 0; i < rows; i++)
    {
        for(j = 0; j < cols; j++)
        {
            if(matrix1[i][j] == 0)
            {
                totalCount++;
            }
        }
    }

    if(totalCount > (rows * cols)/2)
    {
        cout<<"Sparse Matrix";
    }
    else {
        cout<<"Not Sparse Matrix";
    }

    return 0;
}
