#include <iostream>

using namespace std;

//switch-Menu Driven Program

int main()
{
    int choice;
    int a, b;

    while(1){ // for(;;){}

    cout<<"***********Calculator******************"<<endl;
    cout<<"\n\nPress 1. Addition\n";
    cout<<"Press 2. Subtraction\n";
    cout<<"Press 3. Multiplication\n";
    cout<<"Press 4. Division\n";
    cout<<"Press 5. Exit()";

    cout<<"\n\nEnter your choice:";
    cin>>choice;

    switch(choice)
    {
    case 1:
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Addition is: "<<(a + b)<<endl;
        break;

    case 2:
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Subtraction is: "<<(a - b)<<endl;
        break;

    case 3:
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Multiplication is: "<<(a * b)<<endl;
        break;

    case 4:
        cout<<"Enter any value for a and b:";
        cin>>a>>b;

        cout<<"Division is: "<<(a / b)<<endl;
        break;

    case 5:
        exit(0);

    default:
        cout<<"Invalid Choice";

    }
    }

    return 0;
}
