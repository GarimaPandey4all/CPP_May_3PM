#include <iostream>

using namespace std;

/*
    3 types of loops

    1. For loop
    2. While Loop
    3. Do-While Loop
*/


int main()
{
    int n, i;

    cout<<"Enter any number:";
    cin>>n;

    for(i = 1; i <= 10; i++)
    {
        //n * i = n * i
        cout<<n<<" * "<<i<<" = "<<(n * i)<<endl;
    }

    return 0;
}
