#include <iostream>

using namespace std;

int main()
{
    int a, b, temp;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    cout<<"Before swapping the value of a="<<a<<" and b="<<b<<endl;

    temp = a;
    a = b;
    b = temp;

    cout<<"After swapping the value of a="<<a<<" and b="<<b<<endl;

    return 0;
}
