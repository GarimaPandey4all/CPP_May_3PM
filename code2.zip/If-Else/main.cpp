#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    if(a > b)
    {
        cout<<"A is greater";
    }
    else
    {
        cout<<"B is greater";
    }

    return 0;
}
