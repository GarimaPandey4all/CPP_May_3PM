#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

//    cout<<"Before swapping the value of a="<<a<<" and b="<<b<<endl;
//
//    //first way
//
//    //a = 4, b = 5
//    a = a + b; // a = 9
//    b = a - b; // 9 - 5 = 4
//    a = a - b; // 9 - 4 = 5
//
//    cout<<"After swapping the value of a="<<a<<" and b="<<b<<endl;

//    cout<<"Before swapping the value of a="<<a<<" and b="<<b<<endl;
//
//    //second way
//
//    //a = 4, b = 5
//    a = a * b; // a = 20
//    b = a / b; // 20 / 5 = 4
//    a = a / b; // 20 / 4 = 5
//
//    cout<<"After swapping the value of a="<<a<<" and b="<<b<<endl;

    cout<<"Before swapping the value of a="<<a<<" and b="<<b<<endl;

    //third way

    //a = 4, b = 5
    a = a ^ b; // a = 9
    b = a ^ b; // 9 - 5 = 4
    a = a ^ b; // 9 - 4 = 5

    cout<<"After swapping the value of a="<<a<<" and b="<<b<<endl;

    return 0;
}
