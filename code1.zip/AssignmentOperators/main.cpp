#include <iostream>

using namespace std;

int main()
{
    int a = 10;

    //shorthand
    a += 30; // a = a + 30;

    a ^= 50;

    a /= 4;

    return 0;
}
