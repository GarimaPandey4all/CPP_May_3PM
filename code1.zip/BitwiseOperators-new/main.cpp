#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter any value for a and b:";
    cin>>a>>b;

    cout<<"AND Bitwise:"<<(a & b)<<endl;
    cout<<"OR Bitwise:"<<(a | b)<<endl;
    cout<<"X-OR Bitwise:"<<(a ^ b)<<endl;
    cout<<"Left Shift Bitwise:"<<(a<<1)<<endl;
    cout<<"Right Shift Bitwise:"<<(a>>1)<<endl;

    return 0;
}
