#include <iostream>

using namespace std;

int main()
{
    int a, b;

    cout<<"Enter value for a and b:";
    cin>>a>>b;

    cout<<"AND Logical is:"<<(a > b && b < 10)<<endl;
    cout<<"OR Logical is:"<<(a > b || b < 10)<<endl;
    cout<<"NOT Logical is:"<<!(a > b && b < 10)<<endl;

    return 0;
}
